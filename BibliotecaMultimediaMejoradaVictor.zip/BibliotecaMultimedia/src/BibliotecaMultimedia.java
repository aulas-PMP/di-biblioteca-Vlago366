import java.io.File;
import java.net.URL;
import javafx.application.Application;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.*;
import javafx.scene.media.*;
import javafx.stage.DirectoryChooser;
import javafx.stage.FileChooser;
import javafx.stage.Stage;
import javafx.util.Duration;

/**
 * Biblioteca multimedia que permite reproduucir archivos de video y audio en formato mp3, mp4 y wav
 * @author Víctor Lago
 */
public class BibliotecaMultimedia extends Application {

    // Declaración de los elementos de la interfaz de usuario
    private MediaPlayer mediaPlayer;
    private Label tituloArchivo; // Etiqueta para mostrar el nombre del archivo
    private Slider barraProgreso, sliderVolumen; // Controles deslizantes para el progreso y volumen
    private Label tiempoReproduccion; // Etiqueta para mostrar el tiempo de reproducción
    private MediaView mediaView; // Vista de medios (para mostrar videos)
    private ListView<String> listaArchivos; // Lista de archivos multimedia
    private Button btnAumentarVelocidad, btnReducirVelocidad, btnAmpliarVideo, btnReducirVideo; // Botones de control
    private VBox editorVideo, biblioteca; // Contenedores de la interfaz
    private StackPane stackPane; // Contenedor principal de la escena

    // Declaración de los elementos del menú
    @FXML private MenuItem menuAbrir, menuBiblioteca, menuEditorVideo, menuAcercaDe, seleccionarCarpeta;

    /**
     * Ejecuta el programa principal de la aplicación.
     * @param args Argumentos de la línea de comandos
     */
    public static void main(String[] args) {
        launch(args); // Inicia la aplicación JavaFX
    }

    @Override
    public void start(Stage primaryStage) throws Exception {
        // Configura el escenario principal
        primaryStage.setTitle("Biblioteca Multimedia");

        // Carga el archivo FXML que define la interfaz gráfica
        FXMLLoader loader = new FXMLLoader(getClass().getResource("pantalla.fxml"));
        loader.setController(this); // Establece el controlador
        Parent root = loader.load(); // Carga la interfaz

        // Obtiene los controles definidos en el archivo FXML
        tituloArchivo = (Label) root.lookup("#tituloArchivo");
        mediaView = (MediaView) root.lookup("#mediaView");
        barraProgreso = (Slider) root.lookup("#barraProgreso");
        sliderVolumen = (Slider) root.lookup("#sliderVolumen");
        tiempoReproduccion = (Label) root.lookup("#tiempoReproduccion");
        listaArchivos = (ListView<String>) root.lookup("#listaArchivos");
        btnAumentarVelocidad = (Button) root.lookup("#btnAumentarVelocidad");
        btnReducirVelocidad = (Button) root.lookup("#btnReducirVelocidad");
        stackPane = (StackPane) root.lookup("#stackPane");
        btnAmpliarVideo = (Button) root.lookup("#btnAmpliarVideo");
        btnReducirVideo = (Button) root.lookup("#btnReducirVideo");
        mediaView.setPreserveRatio(false); // Desactiva la preservación de proporciones del video

        editorVideo = (VBox) root.lookup("#editor-video");
        biblioteca = (VBox) root.lookup("#biblioteca");

        // Configura las acciones de los botones de ampliación y reducción del video
        btnAmpliarVideo.setOnAction(e -> ajustarTamañoVideo(1.2));
        btnReducirVideo.setOnAction(e -> ajustarTamañoVideo(0.8));

        // Configuración de las acciones del menú
        menuAbrir.setOnAction(e -> abrirArchivo()); // Acción de abrir archivo
        seleccionarCarpeta.setOnAction(e -> selectCarpet()); // Acción para seleccionar carpeta
        menuBiblioteca.setOnAction(e -> togglePanel(biblioteca)); // Acción para mostrar biblioteca
        menuEditorVideo.setOnAction(e -> togglePanel(editorVideo)); // Acción para mostrar editor de video
        menuAcercaDe.setOnAction(e -> mostrarAcercaDe()); // Acción para mostrar información

        // Configura los botones de control de reproducción
        Button btnPlay = (Button) root.lookup("#Play");
        Button btnPause = (Button) root.lookup("#Pause");
        Button btnStop = (Button) root.lookup("#Stop");

        // Acción para reproducir el archivo
        btnPlay.setOnAction(e -> {
            if (mediaPlayer != null) mediaPlayer.play();
        });

        // Acción para pausar la reproducción
        btnPause.setOnAction(e -> {
            if (mediaPlayer != null) mediaPlayer.pause();
        });

        // Acción para detener la reproducción
        btnStop.setOnAction(e -> {
            if (mediaPlayer != null) mediaPlayer.stop();
        });

        // Configura las acciones para cambiar la velocidad del video
        btnAumentarVelocidad.setOnAction(e -> cambiarVelocidad(0.5));
        btnReducirVelocidad.setOnAction(e -> cambiarVelocidad(-0.5));

        // Carga los archivos de la carpeta Multimedia por defecto
        cargarArchivosDeBiblioteca();

        // Acción cuando se selecciona un archivo de la lista
        listaArchivos.setOnMouseClicked(e -> {
            String archivoSeleccionado = listaArchivos.getSelectionModel().getSelectedItem();
            if (archivoSeleccionado != null) {
                File archivo = new File("Multimedia", archivoSeleccionado);
                cargarArchivo(archivo); // Carga el archivo seleccionado
            }
        });

        // Configura el control de volumen con el slider
        sliderVolumen.valueProperty().addListener((obs, oldVal, newVal) -> {
            if (mediaPlayer != null) {
                mediaPlayer.setVolume(newVal.doubleValue()); // Ajusta el volumen
            }
        });

        // Crea la escena y establece el archivo CSS
        Scene scene = new Scene(root, 1200, 600);

        URL cssURL = getClass().getResource("styles.css");
        if (cssURL != null) {
            scene.getStylesheets().add(cssURL.toExternalForm()); // Aplica el CSS
        }

        primaryStage.setScene(scene); // Establece la escena en el escenario
        primaryStage.show(); // Muestra la ventana
    }

    /**
     * Muestra u oculta un panel dependiendo de su visibilidad actual.
     * @param panel El panel a alternar
     */
    private void togglePanel(VBox panel) {
        if (panel.isVisible()) {
            panel.setVisible(false); // Oculta el panel
            panel.setManaged(false); // No permite que el panel ocupe espacio
            if (mediaView != null) {
                ajustarTamañoVideo(1.5); // Ajusta el tamaño a las dimensiones actuales del StackPane
            }
        } else {
            panel.setVisible(true); // Muestra el panel
            panel.setManaged(true); // Permite que el panel ocupe espacio
            
            if (mediaView != null) {
                ajustarTamañoVideo(0.75); // Ajusta el tamaño a las dimensiones actuales del StackPane
            }
        }
    }


    /**
     * Muestra una ventana con información sobre la aplicación.
     */
    private void mostrarAcercaDe() {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle("Acerca de");
        alert.setHeaderText(null);
        alert.setContentText("Autor: Víctor Lago González\n2ºDAM\nTítulo: Biblioteca escolar");
        alert.showAndWait(); // Muestra la ventana de información
    }

    /**
     * Muestra una ventana de error con un mensaje personalizado.
     * @param mensaje El mensaje de error a mostrar
     */
    private void mostrarError(String mensaje) {
        Alert alert = new Alert(Alert.AlertType.ERROR);
        alert.setTitle("Error");
        alert.setHeaderText(null);
        alert.setContentText(mensaje); // Muestra el mensaje de error
        alert.showAndWait();
    }

    /**
     * Abre un archivo multimedia utilizando un selector de archivos.
     */
    private void abrirArchivo() {
        FileChooser fileChooser = new FileChooser();
        fileChooser.getExtensionFilters().add(
                new FileChooser.ExtensionFilter("Archivos Multimedia", "*.mp4", "*.mp3", "*.wav", "*.jpg", "*.png"));
        File archivo = fileChooser.showOpenDialog(null); // Abre el selector de archivos
        if (archivo != null) {
            cargarArchivo(archivo); // Carga el archivo seleccionado
        }
    }

    /**
     * Carga los archivos multimedia de la carpeta 'Multimedia'.
     */
    private void cargarArchivosDeBiblioteca() {
        File carpetaMultimedia = new File("Multimedia");
        if (carpetaMultimedia.exists() && carpetaMultimedia.isDirectory()) {
            File[] archivos = carpetaMultimedia.listFiles((dir, name) -> name.endsWith(".mp4") || name.endsWith(".mp3") || name.endsWith(".wav") || name.endsWith(".jpg") || name.endsWith(".png"));
            if (archivos != null) {
                for (File archivo : archivos) {
                    listaArchivos.getItems().add(archivo.getName()); // Añade los archivos a la lista
                }
            }
        } else {
            mostrarError("La carpeta 'Multimedia' no existe o no es accesible.");
        }
    }

    /**
     * Ajusta el tamaño del video.
     * @param factor El factor por el cual cambiar el tamaño (1.2 para ampliar, 0.8 para reducir)
     */
    private void ajustarTamañoVideo(double factor) {
        if (mediaView != null) {
            double nuevaAnchura = mediaView.getFitWidth() * factor;
            double nuevaAltura = mediaView.getFitHeight() * factor;
            double maxWidth = stackPane.getWidth();
            double maxHeight = stackPane.getHeight();
            nuevaAnchura = Math.min(nuevaAnchura, maxWidth); // Limita el tamaño máximo
            nuevaAltura = Math.min(nuevaAltura, maxHeight);
            if (mediaView.fitWidthProperty().isBound()) {
                mediaView.fitWidthProperty().unbind();
            }
            if (mediaView.fitHeightProperty().isBound()) {
                mediaView.fitHeightProperty().unbind();
            }
            mediaView.setFitWidth(nuevaAnchura); // Establece el nuevo tamaño
            mediaView.setFitHeight(nuevaAltura);
        }
    }

    /**
     * Carga un archivo multimedia y lo reproduce si es compatible.
     * @param archivo El archivo a cargar
     */
    private void cargarArchivo(File archivo) {
        if (mediaPlayer != null) {
            mediaPlayer.stop(); // Detiene el reproductor anterior si existe
            mediaPlayer.dispose(); // Libera los recursos del reproductor anterior
        }
        try {
            String nombreArchivo = archivo.getName().toLowerCase();
            if (nombreArchivo.endsWith(".mp4") || nombreArchivo.endsWith(".mp3") || nombreArchivo.endsWith(".wav")) {
                Media media = new Media(archivo.toURI().toString());
                mediaPlayer = new MediaPlayer(media); // Crea el nuevo reproductor
                if (nombreArchivo.endsWith(".mp4")) {
                    mediaView.setMediaPlayer(mediaPlayer); // Si es video, asigna el reproductor a la vista
                    mediaView.setVisible(true);
                    stackPane.getChildren().setAll(mediaView); // Añade la vista de medios al StackPane

                    // Configura la propiedad de ajuste del video
                    mediaPlayer.setOnReady(() -> {
                        mediaView.fitWidthProperty().bind(stackPane.widthProperty());
                        mediaView.fitHeightProperty().bind(stackPane.heightProperty());
                    });
                    mediaPlayer.play(); // Inicia la reproducción
                } else {
                    // Si es una imagen, la muestra en lugar del video
                    Image imagenFondo = new Image(new File("src/ambipom.png").toURI().toString());
                    ImageView imageView = new ImageView(imagenFondo);
                    imageView.setPreserveRatio(true); // Conserva las proporciones de la imagen
                    imageView.setFitWidth(600); // Ajusta el tamaño
                    imageView.setFitHeight(400);
                    stackPane.getChildren().setAll(imageView); // Añade la imagen al StackPane
                    mediaView.setVisible(false); // Oculta la vista de video
                }
                tituloArchivo.setText("Reproduciendo: " + archivo.getName()); // Muestra el nombre del archivo
                mediaPlayer.setVolume(sliderVolumen.getValue()); // Establece el volumen

                // Actualiza el progreso de la reproducción
                mediaPlayer.currentTimeProperty().addListener((obs, oldTime, newTime) -> {
                    if (mediaPlayer.getTotalDuration() != null) {
                        barraProgreso.setValue(newTime.toSeconds() / mediaPlayer.getTotalDuration().toSeconds());
                        tiempoReproduccion.setText(formatTime(newTime) + " / " + formatTime(mediaPlayer.getTotalDuration()));
                    }
                });

                // Permite al usuario interactuar con la barra de progreso
                barraProgreso.setOnMouseClicked(e -> {
                    if (mediaPlayer != null) {
                        double posicion = barraProgreso.getValue() * mediaPlayer.getTotalDuration().toSeconds();
                        mediaPlayer.seek(Duration.seconds(posicion));
                    }
                });
            } else {
                mostrarError("El archivo no es compatible.");
            }
        } catch (Exception e) {
            mostrarError("Error al cargar el archivo: " + e.getMessage()); // En caso de error al cargar el archivo
        }
    }

    /**
     * Permite al usuario seleccionar una carpeta de archivos multimedia.
     */
    private void selectCarpet() {
        DirectoryChooser directoryChooser = new DirectoryChooser();
        directoryChooser.setTitle("Seleccionar Carpeta Multimedia");

        // Abre el selector de carpetas
        File carpetaSeleccionada = directoryChooser.showDialog(null);
        if (carpetaSeleccionada != null) {
            // Verifica si la carpeta seleccionada es válida
            File carpetaMultimedia = new File(carpetaSeleccionada.getAbsolutePath());
            if (carpetaMultimedia.exists() && carpetaMultimedia.isDirectory()) {
                cargarArchivosDeBiblioteca(carpetaMultimedia); // Carga los archivos de la nueva carpeta
            } else {
                mostrarError("La carpeta seleccionada no es válida.");
            }
        }
    }

    /**
     * Carga los archivos de una carpeta específica de la biblioteca.
     * @param carpetaMultimedia La carpeta a cargar
     */
    private void cargarArchivosDeBiblioteca(File carpetaMultimedia) {
        listaArchivos.getItems().clear(); // Limpia la lista de archivos actual
        if (carpetaMultimedia.exists() && carpetaMultimedia.isDirectory()) {
            File[] archivos = carpetaMultimedia.listFiles((dir, name) -> name.endsWith(".mp4") || name.endsWith(".mp3") || name.endsWith(".wav"));
            if (archivos != null) {
                for (File archivo : archivos) {
                    listaArchivos.getItems().add(archivo.getName()); // Añade los archivos a la lista
                }
            }
        } else {
            mostrarError("La carpeta 'Multimedia' no existe o no es accesible.");
        }
    }

    /**
     * Formatea un objeto Duration en formato de tiempo (minutos:segundos).
     * @param duration La duración a formatear
     * @return El tiempo formateado como cadena
     */
    private String formatTime(Duration duration) {
        int totalSeconds = (int) duration.toSeconds();
        int minutes = totalSeconds / 60;
        int seconds = totalSeconds % 60;
        return String.format("%02d:%02d", minutes, seconds);
    }

    /**
     * Cambia la velocidad de reproducción del archivo.
     * @param incremento El cambio en la velocidad (positivo para aumentar, negativo para reducir)
     */
    private void cambiarVelocidad(double incremento) {
        if (mediaPlayer != null) {
            double velocidadActual = mediaPlayer.getRate();
            mediaPlayer.setRate(velocidadActual + incremento); // Ajusta la velocidad
        }
    }
}
